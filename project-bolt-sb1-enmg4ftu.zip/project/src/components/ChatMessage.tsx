import { format } from 'date-fns';
import { User } from 'lucide-react';
import { clsx } from 'clsx';

interface ChatMessageProps {
  message: string;
  timestamp: string;
  isCurrentUser: boolean;
  email: string;
}

export function ChatMessage({ message, timestamp, isCurrentUser, email }: ChatMessageProps) {
  return (
    <div
      className={clsx(
        'flex items-start gap-2 mb-4',
        isCurrentUser ? 'flex-row-reverse' : 'flex-row'
      )}
    >
      <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
        <User className="w-5 h-5 text-gray-500" />
      </div>
      <div
        className={clsx(
          'max-w-[70%]',
          isCurrentUser ? 'items-end' : 'items-start'
        )}
      >
        <div className="text-sm text-gray-500 mb-1">{email}</div>
        <div
          className={clsx(
            'rounded-lg p-3',
            isCurrentUser
              ? 'bg-blue-500 text-white'
              : 'bg-gray-100 text-gray-900'
          )}
        >
          {message}
        </div>
        <div className="text-xs text-gray-400 mt-1">
          {format(new Date(timestamp), 'HH:mm')}
        </div>
      </div>
    </div>
  );
}